class Talaba:
    """Talaba nomli Class """
    def __init__(self,ism,fam,tyil):
        self.ism = ism
        self.fam = fam
        self.tyil= tyil
        self.bosqich = 1
        def set_bosqich(self,bosqich):
            """Talabaning kursini yangilovchi function"""
            return self.bosqich==bosqich
    def update_bosqich(self):
        """Talabaning kursini yangilovchi"""
        self.bosqich+=1
    def get_info(self):
        """Talaba xaqidagi Malumot"""
        return f"{self.ism} {self.fam} {self.bosqich}-bosqich talabasi"
    def get_name(self):
        """talabaning ismini qaytaruvchi function"""
        return self.ism
    def get_lasname(self):
        """Talabaning familyasini qaytaradi"""
        return self.fam
    def get_fulname(self):
        """talabaning ism va familyasini qaytaradi"""
        return f"{self.ism} {self.fam}"
    def get_age(self,yil):
        """Talabaning yoshini qaytaradi"""
        return yil-self.tyil
class Fan():
    def __init__(self,nomi):
        self.nomi = nomi
        self.talabalar_soni = 0
        self.talabalar = []
    def get_add_student(self,talaba):
        """Fanga talaba qo`shish"""
        self.talabalar.append(talaba)
        self.talabalar_soni+=1
    def get_name(self):
        """fan nomi"""
        return self.nomi
    def get_students(self):
        """fanga yozilgan talabalar haqida malumot"""
        return  [x.get_info(self) for x in self.talabalar]
    def get_student_num(self):
        """fanga yozilgan talabalar soni"""
        return self.talabalar_soni
print(dir(Talaba))
